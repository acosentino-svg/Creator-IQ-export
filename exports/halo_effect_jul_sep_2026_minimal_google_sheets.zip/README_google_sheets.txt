Import into Google Sheets (minimal — 3 tabs)
============================================
1. sheets.google.com → Blank spreadsheet.
2. Import 01_segment_summary.csv → Replace spreadsheet.
3. Import 02_days_since_selection.csv → Insert new sheet.
4. Import 03_creator_timeline.csv → Insert new sheet.

No settings, data-quality checklist, or all-posts dump in minimal mode.
Use full export (no --minimal) if you need those.
